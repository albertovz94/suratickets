<?php

namespace App\Livewire\Layout;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;

class NotificationBell extends Component
{
    public $notifications;
    public $unreadCount;
    public $isOpen = false;

    // Actualiza la cuenta cada 30 segundos (Vía wire:poll en la vista, se remueve el listener de Echo que causaba error)
    // protected $listeners = ['echo:private-App.Models.User.' . 'id' . ',Illuminate\\Notifications\\Events\\BroadcastNotificationCreated' => 'loadNotifications'];

    public function mount()
    {
        $this->loadNotifications();
    }

    public $lastNotificationId = null;

    public function loadNotifications()
    {
        if (Auth::check()) {
            $this->notifications = Auth::user()->notifications()->take(5)->get();
            $this->unreadCount = Auth::user()->unreadNotifications()->count();

            $latest = Auth::user()->unreadNotifications()->first();
            if ($latest) {
                if ($this->lastNotificationId !== $latest->id) {
                    $this->dispatch('notify', message: $latest->data['message']);
                    $this->dispatch('browser-push', [
                        'title' => '🚨 Suraki HelpDesk',
                        'body' => $latest->data['message']
                    ]);
                    $this->lastNotificationId = $latest->id;
                }
            }
        } else {
            $this->notifications = collect();
            $this->unreadCount = 0;
        }
    }

    public function sendTestPush()
    {
        $this->dispatch('browser-push', [
            'title' => '🧪 Notificación de Prueba Suraki',
            'body' => '¡Excelente! Las notificaciones Push en tu navegador y dispositivo funcionan correctamente.'
        ]);
        $this->dispatch('notify', message: 'Notificación de prueba enviada.');
    }

    public function toggle()
    {
        $this->isOpen = !$this->isOpen;
    }

    public function markAsRead($notificationId, $ticketId = null, $requestId = null)
    {
        $notification = Auth::user()->notifications()->find($notificationId);
        if ($notification) {
            $notification->markAsRead();
        }
        $this->loadNotifications();
        $this->isOpen = false;

        if ($ticketId) {
            return redirect()->route('tickets.show', $ticketId);
        }

        if ($requestId) {
            return redirect()->route('requests.index');
        }

        if ($notification && $notification->type === \App\Notifications\PasswordResetAdminNotification::class) {
            return redirect()->route('users.index');
        }
    }

    public function markAllAsRead()
    {
        Auth::user()->unreadNotifications->markAsRead();
        $this->loadNotifications();
    }

    public function render()
    {
        return view('livewire.layout.notification-bell');
    }
}
