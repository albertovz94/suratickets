<span class="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-semibold {{ $classes }}">
    {{ $label }}
</span>
