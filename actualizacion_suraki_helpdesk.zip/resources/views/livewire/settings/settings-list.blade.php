<div class="py-12 animate-fade-in">
    <div class="max-w-[1600px] w-full mx-auto sm:px-6 lg:px-8">
        <div class="bg-white/80 backdrop-blur-xl overflow-hidden shadow-sm sm:rounded-2xl border border-white/50 mb-6 p-8">
            <h2 class="text-3xl font-bold text-gray-900 tracking-tight">Configuración del Sistema</h2>
            <p class="mt-2 text-sm text-gray-600">Administra las sucursales y departamentos de la empresa.</p>
        </div>

        <div class="bg-white/80 backdrop-blur-xl overflow-hidden shadow-sm sm:rounded-2xl border border-white/50 p-6">
            <!-- Tabs -->
            <div class="border-b border-gray-200 mb-6">
                <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                    <button wire:click="setTab('departments')" class="{{ $activeTab === 'departments' ? 'border-suraki-primary text-suraki-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors">
                        Departamentos
                    </button>
                    <button wire:click="setTab('branches')" class="{{ $activeTab === 'branches' ? 'border-suraki-primary text-suraki-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors">
                        Sucursales
                    </button>
                    <button wire:click="setTab('updates')" class="{{ $activeTab === 'updates' ? 'border-suraki-primary text-suraki-primary' : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300' }} whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm transition-colors flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"></path></svg>
                        Actualizar Sistema (ZIP)
                    </button>
                </nav>
            </div>

            <!-- Contenido Departamentos -->
            @if($activeTab === 'departments')
            <div>
                <div class="flex justify-end mb-4">
                    <x-btn-panel wire:click="openDepartmentModal">
                        + Añadir Departamento
                    </x-btn-panel>
                </div>
                
                <table class="min-w-full divide-y divide-gray-200 border rounded-lg overflow-hidden">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Nombre</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Usuarios</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Equipos</th>
                            <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach($departments as $d)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $d->id }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ $d->name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $d->users_count }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $d->devices_count }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button wire:click="openDepartmentModal({{ $d->id }})" class="text-indigo-600 hover:text-indigo-900 mr-3">Editar</button>
                                <button @click="$dispatch('open-confirmation', {
                                    title: '¿Eliminar departamento?',
                                    message: 'Esta acción es irreversible y eliminará el departamento de forma permanente. Solo se completará si no tiene registros asociados.',
                                    confirmText: 'Eliminar departamento',
                                    action: () => @this.deleteDepartment({{ $d->id }})
                                })" class="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300 font-semibold focus:outline-none">Eliminar</button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            @endif

            <!-- Contenido Sucursales -->
            @if($activeTab === 'branches')
            <div>
                <div class="flex justify-end mb-4">
                    <x-btn-panel wire:click="openBranchModal">
                        + Añadir Sucursal
                    </x-btn-panel>
                </div>
                
                <table class="min-w-full divide-y divide-gray-200 border rounded-lg overflow-hidden">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">ID</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Nombre</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Equipos</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Estado</th>
                            <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Acciones</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach($branches as $s)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $s->id }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ $s->name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $s->devices_count }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                @if($s->is_active)
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">Activa</span>
                                @else
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">Inactiva</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <button wire:click="openBranchModal({{ $s->id }})" class="text-indigo-600 hover:text-indigo-900 mr-3">Editar</button>
                                <button @click="$dispatch('open-confirmation', {
                                    title: '¿Eliminar sucursal?',
                                    message: 'Esta acción es irreversible y eliminará la sucursal de forma permanente. Solo se completará si no tiene registros asociados.',
                                    confirmText: 'Eliminar sucursal',
                                    action: () => @this.deleteBranch({{ $s->id }})
                                })" class="text-red-600 dark:text-red-400 hover:text-red-900 dark:hover:text-red-300 font-semibold focus:outline-none">Eliminar</button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            @endif

            <!-- Contenido Actualizaciones ZIP -->
            @if($activeTab === 'updates')
            <div class="max-w-3xl">
                <div class="bg-slate-50 border border-slate-200 rounded-xl p-6 mb-6">
                    <h3 class="text-lg font-bold text-slate-800 flex items-center gap-2 mb-2">
                        <svg class="w-5 h-5 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path></svg>
                        Cargar Paquete de Actualización (.ZIP)
                    </h3>
                    <p class="text-sm text-slate-600 mb-4">
                        Sube el archivo <code>actualizacion_suraki_helpdesk.zip</code> generado localmente. El sistema creará un respaldo de seguridad del código actual automáticamente, reemplazará los archivos necesarios, ejecutará migraciones de base de datos y limpiará la caché.
                    </p>

                    @if($deployMessage)
                        <div class="mb-4 p-4 bg-emerald-50 border border-emerald-200 text-emerald-700 rounded-lg text-sm font-medium">
                            {{ $deployMessage }}
                        </div>
                    @endif

                    @if($deployError)
                        <div class="mb-4 p-4 bg-rose-50 border border-rose-200 text-rose-700 rounded-lg text-sm font-medium">
                            {{ $deployError }}
                        </div>
                    @endif

                    <form wire:submit.prevent="processDeploy" class="space-y-4">
                        <div>
                            <label class="block text-sm font-medium text-gray-700 mb-2">Seleccionar archivo ZIP:</label>
                            <input type="file" wire:model="zip_file" accept=".zip" class="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100 cursor-pointer">
                            <x-input-error :messages="$errors->get('zip_file')" class="mt-2" />
                        </div>

                        <div wire:loading wire:target="zip_file" class="text-xs text-indigo-600 font-medium">
                            Cargando archivo al servidor...
                        </div>

                        <div class="pt-2">
                            <x-btn-panel type="submit" wire:loading.attr="disabled" wire:target="processDeploy">
                                <span wire:loading.remove wire:target="processDeploy">Procesar e Instalar Actualización</span>
                                <span wire:loading wire:target="processDeploy">Procesando y Respaldando...</span>
                            </x-btn-panel>
                        </div>
                    </form>
                </div>
            </div>
            @endif
        </div>
    </div>

    <!-- Modals -->
    @if($showDepartmentModal)
    <div class="fixed z-50 inset-0 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" wire:click="closeDepartmentModal"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                        {{ $department_id ? 'Editar Departamento' : 'Nuevo Departamento' }}
                    </h3>
                    <div class="mt-4">
                        <x-input-label for="department_name" value="Nombre" />
                        <x-text-input wire:model="department_name" id="department_name" class="block mt-1 w-full" type="text" />
                        <x-input-error :messages="$errors->get('department_name')" class="mt-2" />
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <x-btn-panel wire:click="saveDepartment" class="w-full sm:ml-3 sm:w-auto">Guardar</x-btn-panel>
                    <button wire:click="closeDepartmentModal" type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">Cancelar</button>
                </div>
            </div>
        </div>
    </div>
    @endif

    @if($showBranchModal)
    <div class="fixed z-50 inset-0 overflow-y-auto" aria-labelledby="modal-title" role="dialog" aria-modal="true">
        <div class="flex items-end justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
            <div class="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" aria-hidden="true" wire:click="closeBranchModal"></div>
            <span class="hidden sm:inline-block sm:align-middle sm:h-screen" aria-hidden="true">&#8203;</span>
            <div class="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
                <div class="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                    <h3 class="text-lg leading-6 font-medium text-gray-900" id="modal-title">
                        {{ $branch_id ? 'Editar Sucursal' : 'Nueva Sucursal' }}
                    </h3>
                    <div class="mt-4 space-y-4">
                        <div>
                            <x-input-label for="branch_name" value="Nombre" />
                            <x-text-input wire:model="branch_name" id="branch_name" class="block mt-1 w-full" type="text" />
                            <x-input-error :messages="$errors->get('branch_name')" class="mt-2" />
                        </div>
                        <div class="flex items-center">
                            <input wire:model="branch_is_active" id="branch_is_active" type="checkbox" class="rounded border-gray-300 text-suraki-primary shadow-sm focus:ring-suraki-primary">
                            <label for="branch_is_active" class="ml-2 block text-sm text-gray-900">Activa</label>
                        </div>
                    </div>
                </div>
                <div class="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                    <x-btn-panel wire:click="saveBranch" class="w-full sm:ml-3 sm:w-auto">Guardar</x-btn-panel>
                    <button wire:click="closeBranchModal" type="button" class="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm">Cancelar</button>
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
